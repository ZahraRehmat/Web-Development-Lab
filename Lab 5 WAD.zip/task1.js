console.log(typeof 123456n);
console.log(typeof Symbol("Symbol"));