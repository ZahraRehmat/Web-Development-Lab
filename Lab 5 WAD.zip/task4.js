let a=6;

console.log("a++ : "+ a++);
console.log("++a : " + (++a));
console.log("a-- : "+ a--);
console.log("--a : " + (--a));
