const Profile=
{
    username: "zahrarehmat",
    profileName: "Zahra Rehmat",
    posts: 0,
    following:139,
    followers:92,
    
}


console.log("Username: " + Profile.username);
console.log("Name: " + Profile.profileName);
console.log("Posts: " + Profile.posts);
console.log("Followers: " + Profile.followers);
console.log("Following: " + Profile.following);