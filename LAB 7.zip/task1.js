let heading =document.getElementById("mainHeading");
let textNode = document.createTextNode(" : Zahra Rehmat, 53761");

heading.append(textNode);

console.log(mainHeading);