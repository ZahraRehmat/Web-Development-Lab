let array=[2,4,6,8,10,12,14,16,18];
console.log("Original Array");

for(let text of array)
{
    console.log(text);
}

console.log("\n");
console.log("Product of array:");

const product=array.reduce((res , curr) =>
{
    return res*curr;
});

console.log(product);