let array=["Ovex Technologies","ScienceSoft","NEON networks","Developer Bazaar Technologies","Codal"];

console.log("Original Array:");
for(let text1 of array)
{
    console.log(text1);
}
console.log("\n");

//remove the first name
console.log("Removing the first name:");

array.shift();

for(let text2 of array)
{
    console.log(text2);
}
console.log("\n");

// Remove name from middle position and add 
console.log("Removing name from middle and adding another name:");

array.splice(1,1,"Averox");

for(let text3 of array)
{
    console.log(text3);
}
console.log("\n");

//add a new name at the end
console.log("Adding name at the end:");

array.push("Calder Solutions");

for(let text4 of array)
{
    console.log(text4);
}
