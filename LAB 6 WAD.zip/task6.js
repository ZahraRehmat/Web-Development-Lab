const countVowels=(string) =>
    {
        let count=0;
    
        for(let countV of string)
            {
                if (countV == 'a' || countV == 'e' || countV == 'i' || countV == 'o' || countV == 'u'||
                 countV == 'A' || countV == 'E' || countV == 'I' || countV == 'O' || countV == 'U' )
                 count++;
            }
            return count;
    }
    
    let str=prompt("Enter a word: ")
    
    console.log("String : " + str);
    console.log("Vowels : " +countVowels(str));
    