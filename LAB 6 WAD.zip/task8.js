let array=[88,96,26,76,65,40];

console.log("Original array:")
for (let text1 of array)
{
    console.log(text1);
}

console.log("\n");

console.log("Filtering out marks greater than 50:")

let marksGreater= array.filter((marks) =>
{
    return marks>50;
}
);
console.log(marksGreater);