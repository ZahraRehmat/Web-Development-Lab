let array=["Chocolates","Noodles","Biscuits","Chips","Pasta","Mayonnise"];

for(let text of array)
{
    
    console.log(text.toUpperCase());
}