let array=[12,6,4,3,10,7,17,14];
let min=array[0];
let max=array[0];

for(let num of array)
{
    if(num<min)
    {
        min=num;
    }

    if(num>max)
    {

        max=num;
    }
}
console.log("Smallest: " + min  );
console.log("Largest: " + max );